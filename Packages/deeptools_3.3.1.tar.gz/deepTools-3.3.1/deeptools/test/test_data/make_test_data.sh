bamCoverage -b testA.bam -o testA_skipNAs.bw --skipNAs
bamCoverage -b testB.bam -o testB_skipNAs.bw --skipNAs
