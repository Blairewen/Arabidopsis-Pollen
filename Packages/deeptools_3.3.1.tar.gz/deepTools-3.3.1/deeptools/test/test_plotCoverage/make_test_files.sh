plotCoverage --bamfiles ../test_data/test1.bam ../test_data/test2.bam --plotFile plotCoverage_default.png  --plotFileFormat png --outRawCounts outRawCounts_default.tabular
